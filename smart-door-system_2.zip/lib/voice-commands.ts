"use client"

import { useEffect, useState } from "react"

type CommandAction = "lock" | "unlock" | "status" | "help"

interface VoiceCommandOptions {
  onCommand: (action: CommandAction, target?: string) => void
  enabled?: boolean
}

export function useVoiceCommands({ onCommand, enabled = true }: VoiceCommandOptions) {
  const [isListening, setIsListening] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!enabled) return

    // Check if browser supports speech recognition
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      setError("Speech recognition is not supported in this browser.")
      return
    }

    // Initialize speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    const recognition = new SpeechRecognition()

    recognition.continuous = true
    recognition.interimResults = false
    recognition.lang = "en-US"

    recognition.onstart = () => {
      setIsListening(true)
    }

    recognition.onend = () => {
      setIsListening(false)
      if (enabled) {
        // Restart if it was enabled
        recognition.start()
      }
    }

    recognition.onerror = (event) => {
      setError(`Speech recognition error: ${event.error}`)
      setIsListening(false)
    }

    recognition.onresult = (event) => {
      const transcript = event.results[event.results.length - 1][0].transcript.trim().toLowerCase()
      console.log("Voice command detected:", transcript)

      // Process commands
      if (transcript.includes("unlock") || transcript.includes("open")) {
        // Extract door name if present
        const doorMatch = transcript.match(/(?:unlock|open)\s+(?:the\s+)?(.+?)\s*(?:door|$)/i)
        const doorName = doorMatch ? doorMatch[1] : undefined
        onCommand("unlock", doorName)
      } else if (transcript.includes("lock") || transcript.includes("close")) {
        const doorMatch = transcript.match(/(?:lock|close)\s+(?:the\s+)?(.+?)\s*(?:door|$)/i)
        const doorName = doorMatch ? doorMatch[1] : undefined
        onCommand("lock", doorName)
      } else if (transcript.includes("status") || transcript.includes("check")) {
        onCommand("status")
      } else if (transcript.includes("help")) {
        onCommand("help")
      }
    }

    // Start listening
    try {
      recognition.start()
    } catch (err) {
      setError("Failed to start speech recognition")
    }

    // Cleanup
    return () => {
      recognition.stop()
    }
  }, [enabled, onCommand])

  return { isListening, error }
}
