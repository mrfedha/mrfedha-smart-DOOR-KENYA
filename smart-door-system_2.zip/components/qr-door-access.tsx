"use client"

import { useState, useEffect } from "react"
import { QrCode, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"

interface QRDoorAccessProps {
  doorId: number
  doorName: string
  expiryTime?: number // in minutes
  onGenerate?: (code: string) => void
}

export function QRDoorAccess({ doorId, doorName, expiryTime = 30, onGenerate }: QRDoorAccessProps) {
  const [qrCode, setQrCode] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [timeLeft, setTimeLeft] = useState(expiryTime * 60) // in seconds
  const [isGenerating, setIsGenerating] = useState(false)

  // Generate a temporary access code
  const generateAccessCode = () => {
    setIsGenerating(true)

    // Simulate API call to generate code
    setTimeout(() => {
      // In a real app, this would be a secure token from your backend
      const code = `DOOR-${doorId}-${Math.random().toString(36).substring(2, 10).toUpperCase()}`

      // Generate QR code (in a real app, this would be a proper QR code)
      // For demo purposes, we're just using a placeholder
      setQrCode(code)
      setTimeLeft(expiryTime * 60)
      setIsGenerating(false)

      if (onGenerate) {
        onGenerate(code)
      }
    }, 1000)
  }

  // Copy code to clipboard
  const copyToClipboard = () => {
    if (qrCode) {
      navigator.clipboard.writeText(qrCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  // Countdown timer
  useEffect(() => {
    if (!qrCode || timeLeft <= 0) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [qrCode, timeLeft])

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm overflow-hidden">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <QrCode className="mr-2 h-5 w-5 text-blue-400" />
          Temporary Access: {doorName}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {qrCode ? (
          <>
            <div className="bg-white p-4 rounded-lg flex items-center justify-center">
              {/* This would be a real QR code in production */}
              <div className="w-48 h-48 bg-[url('/placeholder.svg?height=192&width=192')] bg-contain bg-center bg-no-repeat" />
            </div>

            <div className="flex items-center justify-between bg-slate-700 p-2 rounded-md">
              <code className="text-sm text-slate-300 font-mono">{qrCode}</code>
              <Button variant="ghost" size="sm" onClick={copyToClipboard} className="text-slate-300 hover:text-white">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>

            <div className="text-center">
              <p className="text-sm text-slate-400">This code will expire in:</p>
              <motion.p
                className={`text-xl font-bold ${timeLeft < 60 ? "text-red-400" : "text-blue-400"}`}
                animate={{ scale: timeLeft < 60 ? [1, 1.05, 1] : 1 }}
                transition={{ repeat: timeLeft < 60 ? Number.POSITIVE_INFINITY : 0, duration: 1 }}
              >
                {formatTime(timeLeft)}
              </motion.p>
            </div>

            <Button
              onClick={generateAccessCode}
              className="w-full bg-blue-600 hover:bg-blue-700"
              disabled={isGenerating}
            >
              Generate New Code
            </Button>
          </>
        ) : (
          <div className="text-center py-6">
            <motion.div
              initial={{ scale: 0.9, opacity: 0.5 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", duration: 1.5 }}
              className="mx-auto mb-4"
            >
              <QrCode className="h-16 w-16 text-blue-400/50" />
            </motion.div>
            <p className="text-slate-400 mb-4">
              Generate a temporary QR code that allows guests to access this door without a permanent account.
            </p>
            <Button onClick={generateAccessCode} className="bg-blue-600 hover:bg-blue-700" disabled={isGenerating}>
              {isGenerating ? "Generating..." : "Generate Access Code"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
