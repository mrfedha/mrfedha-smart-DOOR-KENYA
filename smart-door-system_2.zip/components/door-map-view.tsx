"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Map, DoorClosed, DoorOpen, Home, Maximize, Minimize } from "lucide-react"

interface DoorLocation {
  id: number
  name: string
  status: "locked" | "unlocked"
  x: number // percentage (0-100)
  y: number // percentage (0-100)
  zone: string
}

interface Zone {
  id: string
  name: string
  color: string
}

interface DoorMapViewProps {
  doors: DoorLocation[]
  zones: Zone[]
  onDoorClick?: (doorId: number) => void
  floorPlanUrl?: string
}

export function DoorMapView({
  doors,
  zones,
  onDoorClick,
  floorPlanUrl = "/placeholder.svg?height=400&width=600",
}: DoorMapViewProps) {
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [selectedZone, setSelectedZone] = useState<string | "all">("all")

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const filteredDoors = selectedZone === "all" ? doors : doors.filter((door) => door.zone === selectedZone)

  return (
    <Card className={`bg-slate-800/50 border-slate-700 backdrop-blur-sm ${isFullscreen ? "fixed inset-4 z-50" : ""}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-white flex justify-between items-center">
          <span className="flex items-center">
            <Map className="mr-2 h-5 w-5 text-blue-400" />
            Door Map
          </span>

          <div className="flex items-center space-x-2">
            <div className="flex space-x-1 mr-2">
              <Button
                variant={selectedZone === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedZone("all")}
                className={selectedZone === "all" ? "bg-blue-600 hover:bg-blue-700" : ""}
              >
                All
              </Button>

              {zones.map((zone) => (
                <Button
                  key={zone.id}
                  variant={selectedZone === zone.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedZone(zone.id)}
                  className={selectedZone === zone.id ? `bg-${zone.color}-600 hover:bg-${zone.color}-700` : ""}
                >
                  {zone.name}
                </Button>
              ))}
            </div>

            <Button variant="outline" size="icon" onClick={toggleFullscreen} className="h-8 w-8">
              {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative" style={{ height: isFullscreen ? "calc(100vh - 12rem)" : "400px" }}>
          {/* Floor plan background */}
          <div
            className="absolute inset-0 bg-slate-900 rounded-lg overflow-hidden"
            style={{
              backgroundImage: `url(${floorPlanUrl})`,
              backgroundSize: "contain",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
            }}
          >
            {/* Home icon */}
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="bg-blue-500/20 p-2 rounded-full">
                <Home className="h-6 w-6 text-blue-400" />
              </div>
            </div>

            {/* Zone areas */}
            {zones.map((zone) => (
              <div
                key={zone.id}
                className={`absolute rounded-full bg-${zone.color}-500/10 border border-${zone.color}-500/30`}
                style={{
                  // Random positions for demo
                  left: `${Math.random() * 60 + 20}%`,
                  top: `${Math.random() * 60 + 20}%`,
                  width: "120px",
                  height: "120px",
                  transform: "translate(-50%, -50%)",
                  display: selectedZone === "all" || selectedZone === zone.id ? "block" : "none",
                }}
              >
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full mt-1">
                  <span className={`text-xs text-${zone.color}-400`}>{zone.name}</span>
                </div>
              </div>
            ))}

            {/* Door markers */}
            {filteredDoors.map((door) => (
              <motion.div
                key={door.id}
                className="absolute cursor-pointer"
                style={{
                  left: `${door.x}%`,
                  top: `${door.y}%`,
                }}
                whileHover={{ scale: 1.2 }}
                onClick={() => onDoorClick && onDoorClick(door.id)}
              >
                <div className={`p-1 rounded-full ${door.status === "locked" ? "bg-green-500/20" : "bg-red-500/20"}`}>
                  {door.status === "locked" ? (
                    <DoorClosed className="h-5 w-5 text-green-400" />
                  ) : (
                    <DoorOpen className="h-5 w-5 text-red-400" />
                  )}
                </div>
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 whitespace-nowrap">
                  <span className="text-xs bg-slate-800/80 px-1 py-0.5 rounded text-white">{door.name}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
