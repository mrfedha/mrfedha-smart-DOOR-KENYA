"use client"

import { useEffect, useRef } from "react"

interface AuroraBackgroundProps {
  className?: string
}

export function AuroraBackground({ className = "" }: AuroraBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Aurora wave parameters
    const waves = [
      { color: "rgba(107, 91, 149, 0.3)", speed: 0.003, amplitude: 50, frequency: 0.02 },
      { color: "rgba(184, 169, 201, 0.2)", speed: 0.002, amplitude: 70, frequency: 0.01 },
      { color: "rgba(255, 204, 92, 0.2)", speed: 0.001, amplitude: 60, frequency: 0.015 },
      { color: "rgba(136, 216, 176, 0.2)", speed: 0.0015, amplitude: 80, frequency: 0.008 },
    ]

    let time = 0

    // Animation loop
    const animate = () => {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw each wave
      waves.forEach((wave) => {
        ctx.fillStyle = wave.color
        ctx.beginPath()

        // Start at the left edge, slightly below the top
        ctx.moveTo(0, canvas.height * 0.3)

        // Draw the wave
        for (let x = 0; x < canvas.width; x += 5) {
          const y = canvas.height * 0.3 + Math.sin(x * wave.frequency + time * wave.speed) * wave.amplitude
          ctx.lineTo(x, y)
        }

        // Complete the path down and around
        ctx.lineTo(canvas.width, canvas.height)
        ctx.lineTo(0, canvas.height)
        ctx.closePath()
        ctx.fill()
      })

      // Update time
      time += 1

      // Continue animation
      requestAnimationFrame(animate)
    }

    // Start animation
    animate()

    // Cleanup
    return () => {
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return <canvas ref={canvasRef} className={`fixed inset-0 -z-10 ${className}`} />
}
