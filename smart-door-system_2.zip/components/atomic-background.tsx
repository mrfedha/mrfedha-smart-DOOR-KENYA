"use client"

import { useEffect, useRef } from "react"

interface AtomicBackgroundProps {
  className?: string
}

export function AtomicBackground({ className = "" }: AtomicBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Particle system
    const particles: Particle[] = []
    const connections: Connection[] = []
    const particleCount = 70
    const connectionDistance = 150
    const connectionOpacity = 0.15

    // Particle class
    class Particle {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      color: string

      constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height
        this.size = Math.random() * 1.5 + 0.5
        this.speedX = (Math.random() - 0.5) * 0.5
        this.speedY = (Math.random() - 0.5) * 0.5
        this.color = "#8A8AF2" // Light purple
      }

      update() {
        this.x += this.speedX
        this.y += this.speedY

        // Bounce off edges
        if (this.x > canvas.width || this.x < 0) {
          this.speedX = -this.speedX
        }
        if (this.y > canvas.height || this.y < 0) {
          this.speedY = -this.speedY
        }
      }

      draw() {
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
        ctx.fillStyle = this.color
        ctx.fill()
      }
    }

    // Connection class
    interface Connection {
      p1: Particle
      p2: Particle
      distance: number
    }

    // Initialize particles
    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle())
    }

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update and draw particles
      for (let i = 0; i < particles.length; i++) {
        particles[i].update()
        particles[i].draw()
      }

      // Clear connections
      connections.length = 0

      // Find connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x
          const dy = particles[i].y - particles[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < connectionDistance) {
            connections.push({
              p1: particles[i],
              p2: particles[j],
              distance: distance,
            })
          }
        }
      }

      // Draw connections
      ctx.strokeStyle = "#8A8AF2" // Light purple
      ctx.lineWidth = 0.5

      for (let i = 0; i < connections.length; i++) {
        const opacity = 1 - connections[i].distance / connectionDistance
        ctx.globalAlpha = opacity * connectionOpacity
        ctx.beginPath()
        ctx.moveTo(connections[i].p1.x, connections[i].p1.y)
        ctx.lineTo(connections[i].p2.x, connections[i].p2.y)
        ctx.stroke()
      }

      ctx.globalAlpha = 1

      requestAnimationFrame(animate)
    }

    animate()

    // Cleanup
    return () => {
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return <canvas ref={canvasRef} className={`fixed inset-0 -z-10 bg-black ${className}`} />
}
