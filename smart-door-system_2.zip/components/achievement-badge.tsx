"use client"

import { motion } from "framer-motion"
import { Award, Star, Shield, Zap, Trophy } from "lucide-react"
import { useState } from "react"

export interface Achievement {
  id: string
  title: string
  description: string
  icon: "award" | "star" | "shield" | "zap" | "trophy"
  color: "blue" | "purple" | "green" | "gold" | "red"
  unlocked: boolean
  progress?: number // 0-100
  date?: string
}

interface AchievementBadgeProps {
  achievement: Achievement
  onClick?: (achievement: Achievement) => void
  showDetails?: boolean
}

export function AchievementBadge({ achievement, onClick, showDetails = false }: AchievementBadgeProps) {
  const [isHovered, setIsHovered] = useState(false)

  const iconMap = {
    award: Award,
    star: Star,
    shield: Shield,
    zap: Zap,
    trophy: Trophy,
  }

  const colorMap = {
    blue: "from-blue-600 to-blue-400",
    purple: "from-purple-600 to-purple-400",
    green: "from-green-600 to-green-400",
    gold: "from-amber-500 to-yellow-300",
    red: "from-red-600 to-red-400",
  }

  const IconComponent = iconMap[achievement.icon]

  return (
    <motion.div
      className={`relative rounded-lg overflow-hidden cursor-pointer ${achievement.unlocked ? "" : "opacity-60 grayscale"}`}
      whileHover={{ scale: 1.05 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() => onClick && onClick(achievement)}
    >
      <div className={`bg-gradient-to-r ${colorMap[achievement.color]} p-4 rounded-lg`}>
        <div className="flex items-center">
          <div className="bg-white/20 p-2 rounded-full mr-3">
            <IconComponent className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white">{achievement.title}</h3>
            {showDetails && <p className="text-xs text-white/80">{achievement.description}</p>}
          </div>
        </div>

        {achievement.progress !== undefined && (
          <div className="mt-2">
            <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-white rounded-full" style={{ width: `${achievement.progress}%` }} />
            </div>
            <p className="text-xs text-white/80 mt-1">{achievement.progress}% Complete</p>
          </div>
        )}

        {achievement.unlocked && achievement.date && showDetails && (
          <p className="text-xs text-white/80 mt-2">Unlocked: {achievement.date}</p>
        )}
      </div>

      {isHovered && !showDetails && (
        <motion.div
          className="absolute inset-0 bg-black/70 flex items-center justify-center p-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <p className="text-xs text-center text-white">{achievement.description}</p>
        </motion.div>
      )}
    </motion.div>
  )
}

export function AchievementGrid({ achievements }: { achievements: Achievement[] }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {achievements.map((achievement) => (
        <AchievementBadge key={achievement.id} achievement={achievement} />
      ))}
    </div>
  )
}
