"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "lucide-react"

interface ActivityData {
  hour: number
  day: number
  value: number // 0-10 scale for intensity
}

interface ActivityHeatmapProps {
  data: ActivityData[]
  title?: string
  doorName?: string
}

export function ActivityHeatmap({ data, title = "Door Activity Heatmap", doorName }: ActivityHeatmapProps) {
  const [timeframe, setTimeframe] = useState<"week" | "day">("week")

  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
  const hours = Array.from({ length: 24 }, (_, i) =>
    i === 0 ? "12am" : i === 12 ? "12pm" : i < 12 ? `${i}am` : `${i - 12}pm`,
  )

  // Get color based on intensity (0-10)
  const getColor = (value: number) => {
    if (value === 0) return "bg-slate-800"
    if (value <= 2) return "bg-blue-900/50"
    if (value <= 4) return "bg-blue-700/60"
    if (value <= 6) return "bg-blue-600/70"
    if (value <= 8) return "bg-blue-500/80"
    return "bg-blue-400"
  }

  // Get data for a specific hour and day
  const getValue = (hour: number, day: number) => {
    const entry = data.find((d) => d.hour === hour && d.day === day)
    return entry ? entry.value : 0
  }

  // Render day view (24 hours for a single day)
  const renderDayView = () => {
    // Use current day of week (0-6)
    const today = new Date().getDay()

    return (
      <div className="grid grid-cols-12 gap-1 mt-4">
        {hours.map((hourLabel, hour) => (
          <div key={hour} className="col-span-1">
            <div
              className={`h-8 rounded-md ${getColor(getValue(hour, today))}`}
              title={`${hourLabel}: ${getValue(hour, today)} events`}
            />
            {hour % 2 === 0 && <div className="text-xs text-slate-500 mt-1 text-center">{hourLabel}</div>}
          </div>
        ))}
      </div>
    )
  }

  // Render week view (7 days x 24 hours)
  const renderWeekView = () => {
    return (
      <div className="mt-4">
        <div className="grid grid-cols-[auto,1fr] gap-2">
          <div className="pt-6">
            {/* Time labels on the left */}
            <div className="space-y-6">
              {[0, 6, 12, 18].map((hour) => (
                <div key={hour} className="text-xs text-slate-500 h-6 -mt-3">
                  {hours[hour]}
                </div>
              ))}
            </div>
          </div>

          <div>
            {/* Day labels on top */}
            <div className="grid grid-cols-7 gap-1 mb-1">
              {days.map((day) => (
                <div key={day} className="text-xs text-slate-500 text-center">
                  {day}
                </div>
              ))}
            </div>

            {/* Heatmap grid */}
            <div className="grid grid-cols-7 gap-1">
              {days.map((_, dayIndex) => (
                <div key={dayIndex} className="space-y-1">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23].map(
                    (hour) => (
                      <div
                        key={hour}
                        className={`h-2 rounded-sm ${getColor(getValue(hour, dayIndex))}`}
                        title={`${days[dayIndex]} ${hours[hour]}: ${getValue(hour, dayIndex)} events`}
                      />
                    ),
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-white flex justify-between items-center">
          <span className="flex items-center">
            <Calendar className="mr-2 h-5 w-5 text-blue-400" />
            {title}
            {doorName && <span className="text-slate-400 ml-2 text-sm">({doorName})</span>}
          </span>

          <div className="flex space-x-1">
            <Button
              variant={timeframe === "day" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("day")}
              className={timeframe === "day" ? "bg-blue-600 hover:bg-blue-700" : ""}
            >
              Day
            </Button>
            <Button
              variant={timeframe === "week" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("week")}
              className={timeframe === "week" ? "bg-blue-600 hover:bg-blue-700" : ""}
            >
              Week
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {timeframe === "day" ? renderDayView() : renderWeekView()}

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-sm bg-slate-800"></div>
            <span className="text-xs text-slate-500">Low</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-sm bg-blue-700/60"></div>
            <span className="text-xs text-slate-500">Medium</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 rounded-sm bg-blue-400"></div>
            <span className="text-xs text-slate-500">High</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
