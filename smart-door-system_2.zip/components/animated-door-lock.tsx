"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Lock, Unlock } from "lucide-react"

interface AnimatedDoorLockProps {
  isLocked: boolean
  onToggle: () => void
  size?: "sm" | "md" | "lg"
  showLabel?: boolean
  className?: string
}

export function AnimatedDoorLock({
  isLocked,
  onToggle,
  size = "md",
  showLabel = true,
  className = "",
}: AnimatedDoorLockProps) {
  const [isAnimating, setIsAnimating] = useState(false)

  // Size mappings
  const sizeMap = {
    sm: {
      icon: "h-6 w-6",
      container: "h-12 w-12",
      text: "text-xs",
    },
    md: {
      icon: "h-8 w-8",
      container: "h-16 w-16",
      text: "text-sm",
    },
    lg: {
      icon: "h-10 w-10",
      container: "h-20 w-20",
      text: "text-base",
    },
  }

  // Handle animation
  useEffect(() => {
    if (isAnimating) {
      const timer = setTimeout(() => {
        setIsAnimating(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [isAnimating])

  const handleClick = () => {
    setIsAnimating(true)
    onToggle()
  }

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <motion.div
        className={`${sizeMap[size].container} rounded-full flex items-center justify-center cursor-pointer border-2
          ${
            isLocked
              ? "bg-green-500/10 text-green-400 border-green-500/30 hover:bg-green-500/20"
              : "bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20"
          }`}
        onClick={handleClick}
        whileTap={{ scale: 0.95 }}
        animate={
          isAnimating
            ? {
                rotate: [0, -10, 10, -5, 5, 0],
                transition: { duration: 0.5 },
              }
            : {}
        }
      >
        {isLocked ? <Lock className={sizeMap[size].icon} /> : <Unlock className={sizeMap[size].icon} />}
      </motion.div>

      {showLabel && (
        <p className={`mt-2 ${sizeMap[size].text} ${isLocked ? "text-green-400" : "text-red-400"}`}>
          {isLocked ? "Locked" : "Unlocked"}
        </p>
      )}
    </div>
  )
}
