"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Shield, Lock } from "lucide-react"

interface BootAnimationProps {
  onComplete: () => void
  duration?: number // in milliseconds
}

export function BootAnimation({ onComplete, duration = 3000 }: BootAnimationProps) {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 1
        if (newProgress >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            onComplete()
          }, 500)
        }
        return newProgress > 100 ? 100 : newProgress
      })
    }, duration / 100)

    return () => clearInterval(interval)
  }, [duration, onComplete])

  const messages = [
    { threshold: 10, text: "Initializing Security Protocol..." },
    { threshold: 25, text: "Validating Credentials..." },
    { threshold: 40, text: "Establishing Secure Connection..." },
    { threshold: 60, text: "Loading Door Control Systems..." },
    { threshold: 80, text: "Preparing Dashboard..." },
    { threshold: 95, text: "Ready to Secure Your Doors..." },
    { threshold: 100, text: "Welcome to Smart Door System!" },
  ]

  const currentMessage = messages.reduce((acc, msg) => (progress >= msg.threshold ? msg : acc), messages[0])

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50">
      {/* Animated atoms in background */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-indigo-400 rounded-full"
            initial={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
              opacity: 0.3 + Math.random() * 0.7,
            }}
            animate={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
              opacity: [0.3, 0.7, 0.3],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 3 + Math.random() * 5,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="mb-8 relative"
      >
        <div className="w-24 h-24 rounded-full border-4 border-indigo-600/30 flex items-center justify-center">
          <motion.div
            animate={{
              rotate: 360,
              transition: { duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "linear" },
            }}
          >
            <Lock className="h-12 w-12 text-indigo-500" />
          </motion.div>
        </div>

        {/* Orbiting particle */}
        <motion.div
          className="absolute w-3 h-3 bg-indigo-500 rounded-full"
          animate={{
            rotate: 360,
            transition: { duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "linear" },
          }}
          style={{
            transformOrigin: "center center",
            left: "calc(50% - 1.5px)",
            top: "calc(50% - 1.5px)",
            transform: `translateX(-50px) translateY(-50px) rotate(0deg) translateX(50px) translateY(50px)`,
          }}
        />
      </motion.div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Smart Door System</h1>
        <motion.p
          key={currentMessage.text}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-indigo-300"
        >
          {currentMessage.text}
        </motion.p>
      </motion.div>

      <div className="w-64 h-2 bg-zinc-800 rounded-full overflow-hidden">
        <motion.div className="h-full bg-indigo-600" style={{ width: `${progress}%` }} initial={{ width: "0%" }} />
      </div>

      <div className="mt-8 flex space-x-4">
        <motion.div
          animate={{
            y: [0, -5, 0],
            transition: { duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0 },
          }}
        >
          <Shield className="h-6 w-6 text-indigo-400" />
        </motion.div>
        <motion.div
          animate={{
            y: [0, -5, 0],
            transition: { duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.5 },
          }}
        >
          <Lock className="h-6 w-6 text-indigo-400" />
        </motion.div>
        <motion.div
          animate={{
            y: [0, -5, 0],
            transition: { duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 1 },
          }}
        >
          <Shield className="h-6 w-6 text-indigo-400" />
        </motion.div>
      </div>
    </div>
  )
}
