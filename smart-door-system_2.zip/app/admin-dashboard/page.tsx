"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import {
  Bell,
  LogOut,
  Download,
  Search,
  User,
  Users,
  DoorClosed,
  MessageSquare,
  Settings,
  Home,
  Trash2,
  Filter,
  ChevronDown,
  CheckCircle,
  Battery,
  Clock,
  Server,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Mock data for users
const initialUsers = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    location: "New York",
    doorCount: 2,
    lastActive: "Today, 10:23 AM",
    status: "active",
    photo: "/user-profile-1.png",
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1 (555) 987-6543",
    location: "Los Angeles",
    doorCount: 1,
    lastActive: "Yesterday, 8:15 PM",
    status: "active",
    photo: "/user-profile-2.png",
  },
  {
    id: 3,
    name: "Robert Johnson",
    email: "robert@example.com",
    phone: "+1 (555) 456-7890",
    location: "Chicago",
    doorCount: 3,
    lastActive: "3 days ago",
    status: "inactive",
    photo: "/user-profile-3.png",
  },
]

// Mock data for doors
const initialDoors = [
  {
    id: 1,
    userId: 1,
    userName: "John Doe",
    name: "Front Door",
    status: "locked",
    battery: 87,
    lastActivity: "Today, 10:23 AM",
  },
  {
    id: 2,
    userId: 1,
    userName: "John Doe",
    name: "Back Door",
    status: "unlocked",
    battery: 64,
    lastActivity: "Yesterday, 8:15 PM",
  },
  {
    id: 3,
    userId: 2,
    userName: "Jane Smith",
    name: "Main Door",
    status: "locked",
    battery: 92,
    lastActivity: "Today, 9:45 AM",
  },
  {
    id: 4,
    userId: 3,
    userName: "Robert Johnson",
    name: "Front Door",
    status: "locked",
    battery: 23,
    lastActivity: "3 days ago",
  },
  {
    id: 5,
    userId: 3,
    userName: "Robert Johnson",
    name: "Side Door",
    status: "locked",
    battery: 45,
    lastActivity: "4 days ago",
  },
  {
    id: 6,
    userId: 3,
    userName: "Robert Johnson",
    name: "Garage Door",
    status: "locked",
    battery: 78,
    lastActivity: "3 days ago",
  },
]

// Mock data for logs
const initialLogs = [
  {
    id: 1,
    userId: 1,
    userName: "John Doe",
    doorId: 1,
    doorName: "Front Door",
    action: "unlock",
    timestamp: "Today, 10:23 AM",
  },
  {
    id: 2,
    userId: 1,
    userName: "John Doe",
    doorId: 1,
    doorName: "Front Door",
    action: "lock",
    timestamp: "Today, 10:30 AM",
  },
  {
    id: 3,
    userId: 2,
    userName: "Jane Smith",
    doorId: 3,
    doorName: "Main Door",
    action: "unlock",
    timestamp: "Today, 9:45 AM",
  },
  {
    id: 4,
    userId: 1,
    userName: "John Doe",
    doorId: 2,
    doorName: "Back Door",
    action: "unlock",
    timestamp: "Yesterday, 8:15 PM",
  },
  {
    id: 5,
    userId: 3,
    userName: "Robert Johnson",
    doorId: 4,
    doorName: "Front Door",
    action: "lock",
    timestamp: "3 days ago",
  },
]

// Mock data for messages
const initialMessages = [
  {
    id: 1,
    userId: 1,
    userName: "John Doe",
    content: "I'm having trouble with my front door lock. It's not responding.",
    timestamp: "Today, 11:30 AM",
    read: false,
  },
  {
    id: 2,
    userId: 2,
    userName: "Jane Smith",
    content: "When will the battery replacement service be available?",
    timestamp: "Yesterday, 3:45 PM",
    read: true,
  },
]

export default function AdminDashboard() {
  const { toast } = useToast()
  const [currentTime, setCurrentTime] = useState("")
  const [users, setUsers] = useState(initialUsers)
  const [doors, setDoors] = useState(initialDoors)
  const [logs, setLogs] = useState(initialLogs)
  const [messages, setMessages] = useState(initialMessages)
  const [searchTerm, setSearchTerm] = useState("")
  const [systemOnline, setSystemOnline] = useState(true)
  const [activeTab, setActiveTab] = useState("users")
  const [selectedMessage, setSelectedMessage] = useState(null)
  const [replyText, setReplyText] = useState("")
  const [userFilter, setUserFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [batteryFilter, setBatteryFilter] = useState("all")
  const [notifications, setNotifications] = useState([
    { id: 1, title: "New User", message: "Jane Smith has registered", time: "10 minutes ago", read: false },
    { id: 2, title: "Low Battery", message: "Front Door battery is below 30%", time: "1 hour ago", read: false },
    { id: 3, title: "Door Unlocked", message: "Back Door was unlocked remotely", time: "Yesterday", read: true },
  ])
  const [showNotifications, setShowNotifications] = useState(false)
  const [showSettings, setShowSettings] = useState(false)

  // Update current time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const options = {
        hour: "numeric",
        minute: "numeric",
        hour12: true,
      }
      setCurrentTime(now.toLocaleTimeString(undefined, options))
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)

    return () => clearInterval(interval)
  }, [])

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Simplified event handler with less DOM traversal
      if (showNotifications || showSettings) {
        const target = event.target
        if (!target.closest(".dropdown-container")) {
          setShowNotifications(false)
          setShowSettings(false)
        }
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [showNotifications, showSettings])

  const toggleSystemStatus = () => {
    setSystemOnline(!systemOnline)

    toast({
      title: systemOnline ? "System Offline" : "System Online",
      description: systemOnline
        ? "The system has been set to offline mode."
        : "The system is now online and operational.",
    })
  }

  const deleteUser = (userId) => {
    setUsers(users.filter((user) => user.id !== userId))
    setDoors(doors.filter((door) => door.userId !== userId))
    setLogs(logs.filter((log) => log.userId !== userId))
    setMessages(messages.filter((message) => message.userId !== userId))

    toast({
      title: "User Deleted",
      description: "User and all associated data have been removed.",
    })
  }

  const deleteMessage = (messageId) => {
    setMessages(messages.filter((message) => message.id !== messageId))

    toast({
      title: "Message Deleted",
      description: "The message has been deleted.",
    })
  }

  const markAsRead = (messageId) => {
    setMessages(messages.map((message) => (message.id === messageId ? { ...message, read: true } : message)))
  }

  const sendReply = () => {
    if (!replyText.trim() || !selectedMessage) return

    toast({
      title: "Reply Sent",
      description: `Your reply to ${selectedMessage.userName} has been sent.`,
    })

    setReplyText("")
    setSelectedMessage(null)
  }

  const downloadLogs = (format) => {
    toast({
      title: `Logs Downloaded`,
      description: `Logs have been downloaded in ${format.toUpperCase()} format.`,
    })
  }

  // Filter functions
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.location.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || user.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const filteredDoors = doors.filter((door) => {
    const matchesSearch =
      door.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      door.userName.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesUser = userFilter === "all" || door.userId === Number.parseInt(userFilter)

    const matchesBattery =
      batteryFilter === "all" ||
      (batteryFilter === "low" && door.battery < 30) ||
      (batteryFilter === "medium" && door.battery >= 30 && door.battery < 70) ||
      (batteryFilter === "high" && door.battery >= 70)

    return matchesSearch && matchesUser && matchesBattery
  })

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.doorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesUser = userFilter === "all" || log.userId === Number.parseInt(userFilter)

    return matchesSearch && matchesUser
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Animated background elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-red-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute bottom-20 right-10 w-80 h-80 bg-orange-500/5 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <div className="mr-4 p-2 rounded-full bg-red-500/10">
              <Home className="h-6 w-6 text-red-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
              <p className="text-slate-400 text-sm">
                <span className="font-medium">{currentTime}</span> •
                <span className={systemOnline ? "text-green-400" : "text-red-400"}>
                  {" "}
                  System {systemOnline ? "Online" : "Offline"}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-400">System Status:</span>
              <Switch checked={systemOnline} onCheckedChange={toggleSystemStatus} />
            </div>
            <div className="relative dropdown-container">
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-400 hover:text-white hover:bg-slate-800"
                onClick={() => {
                  setShowNotifications(!showNotifications)
                  setShowSettings(false)
                }}
              >
                <Bell className="h-5 w-5" />
                {notifications.filter((n) => !n.read).length > 0 && (
                  <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center">
                    {notifications.filter((n) => !n.read).length}
                  </span>
                )}
              </Button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-slate-800 border border-slate-700 rounded-md shadow-lg z-[100]">
                  <div className="p-3 border-b border-slate-700 flex justify-between items-center">
                    <h3 className="font-medium text-white">Notifications</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs text-blue-400 hover:text-blue-300"
                      onClick={() => {
                        setNotifications(notifications.map((n) => ({ ...n, read: true })))
                      }}
                    >
                      Mark all as read
                    </Button>
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-3 border-b border-slate-700 hover:bg-slate-700/50 cursor-pointer ${!notification.read ? "bg-slate-700/30" : ""}`}
                          onClick={() => {
                            setNotifications(
                              notifications.map((n) => (n.id === notification.id ? { ...n, read: true } : n)),
                            )
                          }}
                        >
                          <div className="flex justify-between">
                            <h4 className="font-medium text-white">{notification.title}</h4>
                            {!notification.read && <span className="w-2 h-2 bg-blue-500 rounded-full"></span>}
                          </div>
                          <p className="text-sm text-slate-300 mt-1">{notification.message}</p>
                          <p className="text-xs text-slate-400 mt-1">{notification.time}</p>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 text-center text-slate-400">No notifications</div>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="relative dropdown-container">
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-400 hover:text-white hover:bg-slate-800"
                onClick={() => {
                  setShowSettings(!showSettings)
                  setShowNotifications(false)
                }}
              >
                <Settings className="h-5 w-5" />
              </Button>

              {showSettings && (
                <div className="absolute right-0 mt-2 w-64 bg-slate-800 border border-slate-700 rounded-md shadow-lg z-[100]">
                  <div className="p-3 border-b border-slate-700">
                    <h3 className="font-medium text-white">System Settings</h3>
                  </div>
                  <div>
                    <div className="p-3 border-b border-slate-700 hover:bg-slate-700/50 cursor-pointer">
                      <p className="text-sm text-slate-300">Admin Profile</p>
                    </div>
                    <div className="p-3 border-b border-slate-700 hover:bg-slate-700/50 cursor-pointer">
                      <p className="text-sm text-slate-300">Security Settings</p>
                    </div>
                    <div className="p-3 border-b border-slate-700 hover:bg-slate-700/50 cursor-pointer">
                      <p className="text-sm text-slate-300">Notification Preferences</p>
                    </div>
                    <div className="p-3 hover:bg-slate-700/50 cursor-pointer">
                      <p className="text-sm text-slate-300">System Maintenance</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white hover:bg-slate-800">
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-slate-800 border-slate-700 text-white w-64"
              />
            </div>

            {activeTab === "users" && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="bg-slate-800 border-slate-700 text-white">
                    <Filter className="mr-2 h-4 w-4" />
                    Status
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                  <DropdownMenuItem onClick={() => setStatusFilter("all")}>All</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("active")}>Active</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setStatusFilter("inactive")}>Inactive</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {(activeTab === "doors" || activeTab === "logs") && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="bg-slate-800 border-slate-700 text-white">
                    <User className="mr-2 h-4 w-4" />
                    User
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                  <DropdownMenuItem onClick={() => setUserFilter("all")}>All Users</DropdownMenuItem>
                  {users.map((user) => (
                    <DropdownMenuItem key={user.id} onClick={() => setUserFilter(user.id.toString())}>
                      {user.name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {activeTab === "doors" && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="bg-slate-800 border-slate-700 text-white">
                    <Battery className="mr-2 h-4 w-4" />
                    Battery
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                  <DropdownMenuItem onClick={() => setBatteryFilter("all")}>All</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setBatteryFilter("low")}>Low (&lt;30%)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setBatteryFilter("medium")}>Medium (30-70%)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setBatteryFilter("high")}>High (&gt;70%)</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>

          {activeTab === "logs" && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="bg-slate-800 border-slate-700 text-white">
                  <Download className="mr-2 h-4 w-4" />
                  Download Logs
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-800 border-slate-700 text-white">
                <DropdownMenuItem onClick={() => downloadLogs("pdf")}>PDF Format</DropdownMenuItem>
                <DropdownMenuItem onClick={() => downloadLogs("csv")}>CSV Format</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        <Tabs defaultValue="users" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="users" className="data-[state=active]:bg-red-600">
              <Users className="mr-2 h-4 w-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="doors" className="data-[state=active]:bg-red-600">
              <DoorClosed className="mr-2 h-4 w-4" />
              Doors
            </TabsTrigger>
            <TabsTrigger value="logs" className="data-[state=active]:bg-red-600">
              <Clock className="mr-2 h-4 w-4" />
              Logs
            </TabsTrigger>
            <TabsTrigger value="messages" className="data-[state=active]:bg-red-600">
              <MessageSquare className="mr-2 h-4 w-4" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="hardware" className="data-[state=active]:bg-red-600">
              <Server className="mr-2 h-4 w-4" />
              Hardware
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Registered Users</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader className="bg-slate-900/50">
                    <TableRow>
                      <TableHead className="text-slate-300">Photo</TableHead>
                      <TableHead className="text-slate-300">Name</TableHead>
                      <TableHead className="text-slate-300">Email</TableHead>
                      <TableHead className="text-slate-300">Phone</TableHead>
                      <TableHead className="text-slate-300">Location</TableHead>
                      <TableHead className="text-slate-300">Doors</TableHead>
                      <TableHead className="text-slate-300">Last Active</TableHead>
                      <TableHead className="text-slate-300">Status</TableHead>
                      <TableHead className="text-slate-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.length > 0 ? (
                      filteredUsers.map((user) => (
                        <TableRow key={user.id} className="border-slate-700">
                          <TableCell>
                            <div className="w-10 h-10 rounded-full overflow-hidden border border-slate-600">
                              <img
                                src={user.photo || "/placeholder.svg?height=40&width=40"}
                                alt={user.name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          </TableCell>
                          <TableCell className="font-medium text-white">{user.name}</TableCell>
                          <TableCell className="text-slate-300">{user.email}</TableCell>
                          <TableCell className="text-slate-300">{user.phone}</TableCell>
                          <TableCell className="text-slate-300">{user.location}</TableCell>
                          <TableCell className="text-slate-300">{user.doorCount}</TableCell>
                          <TableCell className="text-slate-300">{user.lastActive}</TableCell>
                          <TableCell>
                            <Badge className={user.status === "active" ? "bg-green-500" : "bg-red-500"}>
                              {user.status === "active" ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                              onClick={() => deleteUser(user.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={9} className="text-center text-slate-400 py-4">
                          No users found matching your search criteria.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="doors" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Door Status</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader className="bg-slate-900/50">
                    <TableRow>
                      <TableHead className="text-slate-300">User</TableHead>
                      <TableHead className="text-slate-300">Door Name</TableHead>
                      <TableHead className="text-slate-300">Status</TableHead>
                      <TableHead className="text-slate-300">Battery</TableHead>
                      <TableHead className="text-slate-300">Last Activity</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDoors.length > 0 ? (
                      filteredDoors.map((door) => (
                        <TableRow key={door.id} className="border-slate-700">
                          <TableCell className="font-medium text-white">{door.userName}</TableCell>
                          <TableCell className="text-slate-300">{door.name}</TableCell>
                          <TableCell>
                            <Badge className={door.status === "locked" ? "bg-green-500" : "bg-red-500"}>
                              {door.status === "locked" ? "Locked" : "Unlocked"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="w-full max-w-24">
                                <div className="h-2 w-full bg-slate-700 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full rounded-full ${
                                      door.battery > 70
                                        ? "bg-green-500"
                                        : door.battery > 30
                                          ? "bg-yellow-500"
                                          : "bg-red-500"
                                    }`}
                                    style={{ width: `${door.battery}%` }}
                                  ></div>
                                </div>
                              </div>
                              <span className="text-sm text-slate-300">{door.battery}%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-slate-300">{door.lastActivity}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-slate-400 py-4">
                          No doors found matching your search criteria.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Activity Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader className="bg-slate-900/50">
                    <TableRow>
                      <TableHead className="text-slate-300">Timestamp</TableHead>
                      <TableHead className="text-slate-300">User</TableHead>
                      <TableHead className="text-slate-300">Door</TableHead>
                      <TableHead className="text-slate-300">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.length > 0 ? (
                      filteredLogs.map((log) => (
                        <TableRow key={log.id} className="border-slate-700">
                          <TableCell className="text-slate-300">{log.timestamp}</TableCell>
                          <TableCell className="font-medium text-white">{log.userName}</TableCell>
                          <TableCell className="text-slate-300">{log.doorName}</TableCell>
                          <TableCell>
                            <Badge className={log.action === "lock" ? "bg-green-500" : "bg-blue-500"}>
                              {log.action === "lock" ? "Locked" : "Unlocked"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-slate-400 py-4">
                          No logs found matching your search criteria.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">User Messages</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader className="bg-slate-900/50">
                    <TableRow>
                      <TableHead className="text-slate-300">Status</TableHead>
                      <TableHead className="text-slate-300">User</TableHead>
                      <TableHead className="text-slate-300">Message</TableHead>
                      <TableHead className="text-slate-300">Timestamp</TableHead>
                      <TableHead className="text-slate-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {messages.length > 0 ? (
                      messages.map((message) => (
                        <TableRow key={message.id} className="border-slate-700">
                          <TableCell>
                            {message.read ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : (
                              <div className="flex items-center">
                                <div className="w-2 h-2 rounded-full bg-blue-500 mr-2 animate-pulse"></div>
                                <span className="text-blue-400 text-sm">New</span>
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="font-medium text-white">{message.userName}</TableCell>
                          <TableCell className="text-slate-300 max-w-xs truncate">{message.content}</TableCell>
                          <TableCell className="text-slate-300">{message.timestamp}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="h-8 border-slate-700 bg-slate-800 text-white hover:bg-slate-700"
                                    onClick={() => {
                                      setSelectedMessage(message)
                                      markAsRead(message.id)
                                    }}
                                  >
                                    Reply
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="bg-slate-800 border-slate-700 text-white">
                                  <DialogHeader>
                                    <DialogTitle>Reply to {selectedMessage?.userName}</DialogTitle>
                                    <DialogDescription className="text-slate-400">
                                      Send a response to the user's message.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="bg-slate-900 p-4 rounded-md my-4">
                                    <p className="text-slate-300">{selectedMessage?.content}</p>
                                    <p className="text-xs text-slate-500 mt-2">{selectedMessage?.timestamp}</p>
                                  </div>
                                  <div className="space-y-4">
                                    <textarea
                                      value={replyText}
                                      onChange={(e) => setReplyText(e.target.value)}
                                      placeholder="Type your reply..."
                                      className="w-full h-32 bg-slate-700 border-slate-600 text-white rounded-md p-2"
                                    />
                                    <Button onClick={sendReply} className="w-full bg-red-600 hover:bg-red-700">
                                      Send Reply
                                    </Button>
                                  </div>
                                </DialogContent>
                              </Dialog>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                                onClick={() => deleteMessage(message.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-slate-400 py-4">
                          No messages found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="hardware" className="mt-6">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">ESP32 Hardware Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <HardwareStatusCard
                    name="Main Controller"
                    status={true}
                    lastSeen="Just now"
                    ipAddress="192.168.1.100"
                    version="v1.2.3"
                  />
                  <HardwareStatusCard
                    name="Door Sensor Hub"
                    status={true}
                    lastSeen="2 minutes ago"
                    ipAddress="192.168.1.101"
                    version="v1.2.1"
                  />
                  <HardwareStatusCard
                    name="Lock Controller"
                    status={true}
                    lastSeen="5 minutes ago"
                    ipAddress="192.168.1.102"
                    version="v1.2.2"
                  />
                  <HardwareStatusCard
                    name="Motion Sensor"
                    status={false}
                    lastSeen="2 hours ago"
                    ipAddress="192.168.1.103"
                    version="v1.1.8"
                  />
                  <HardwareStatusCard
                    name="Camera Module"
                    status={true}
                    lastSeen="10 minutes ago"
                    ipAddress="192.168.1.104"
                    version="v1.3.0"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function HardwareStatusCard({ name, status, lastSeen, ipAddress, version }) {
  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-lg font-medium text-white">{name}</h3>
          <Badge className={status ? "bg-green-500" : "bg-red-500"}>{status ? "Online" : "Offline"}</Badge>
        </div>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-400">Last Seen:</span>
            <span className="text-slate-300">{lastSeen}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">IP Address:</span>
            <span className="text-slate-300">{ipAddress}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Firmware:</span>
            <span className="text-slate-300">{version}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
