"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Bell, LogOut, Plus, Battery, Clock, MessageSquare, Settings, Home, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"

// Import our components
import { useVoiceCommands } from "@/lib/voice-commands"
import { BootAnimation } from "@/components/boot-animation"
import { AtomicBackground } from "@/components/atomic-background"
import { AnimatedDoorLock } from "@/components/animated-door-lock"

// Mock data for doors
const initialDoors = [
  {
    id: 1,
    name: "Front Door",
    status: "locked",
    battery: 87,
    lastActivity: "Today, 10:23 AM",
    schedule: "10:00 PM",
    autoLock: true,
    sensors: ["lock", "contact", "temperature"],
  },
  {
    id: 2,
    name: "Back Door",
    status: "unlocked",
    battery: 64,
    lastActivity: "Yesterday, 8:15 PM",
    schedule: "9:30 PM",
    autoLock: true,
    sensors: ["lock", "camera"],
  },
]

// Sensor types
const availableSensors = [
  { id: "lock", name: "Smart Lock", description: "Lock/unlock door remotely" },
  { id: "contact", name: "Contact Sensor", description: "Detect if door is open or closed" },
  { id: "motion", name: "Motion Sensor", description: "Detect motion near the door" },
  { id: "camera", name: "Camera", description: "View live feed of door area" },
  { id: "fingerprint", name: "Fingerprint Scanner", description: "Biometric access control" },
  { id: "keypad", name: "Keypad", description: "PIN code access" },
  { id: "temperature", name: "Temperature Sensor", description: "Monitor temperature near door" },
]

export default function Dashboard() {
  const { toast } = useToast()
  const [doors, setDoors] = useState(initialDoors)
  const [currentTime, setCurrentTime] = useState("")
  const [newDoorName, setNewDoorName] = useState("")
  const [selectedSensors, setSelectedSensors] = useState<string[]>(["lock"])
  const [messages, setMessages] = useState([
    {
      id: 1,
      content: "Welcome to Smart Door System! Let us know if you need any help.",
      isAdmin: true,
      timestamp: "Today, 9:00 AM",
    },
  ])
  const [newMessage, setNewMessage] = useState("")
  const [activeTab, setActiveTab] = useState("doors")
  const [notifications, setNotifications] = useState([
    { id: 1, title: "Door Unlocked", message: "Front Door was unlocked", time: "Just now", read: false },
    { id: 2, title: "Low Battery", message: "Back Door battery is low", time: "1 hour ago", read: false },
  ])
  const [showNotifications, setShowNotifications] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [showBootAnimation, setShowBootAnimation] = useState(true)
  const [voiceCommandActive, setVoiceCommandActive] = useState(true)

  // Update current time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const options = {
        hour: "numeric",
        minute: "numeric",
        hour12: true,
      }
      setCurrentTime(now.toLocaleTimeString(undefined, options))
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)

    return () => clearInterval(interval)
  }, [])

  // Voice command handler
  const handleVoiceCommand = (action: "lock" | "unlock" | "status" | "help", target?: string) => {
    if (action === "lock" || action === "unlock") {
      // Find the door by name if target is provided
      let doorToToggle = doors[0] // Default to first door

      if (target) {
        const matchedDoor = doors.find((door) => door.name.toLowerCase().includes(target.toLowerCase()))

        if (matchedDoor) {
          doorToToggle = matchedDoor
        } else {
          toast({
            title: "Door not found",
            description: `Could not find a door named "${target}"`,
            variant: "destructive",
          })
          return
        }
      }

      // Only toggle if the current status doesn't match the requested action
      if (
        (action === "lock" && doorToToggle.status === "unlocked") ||
        (action === "unlock" && doorToToggle.status === "locked")
      ) {
        toggleDoorStatus(doorToToggle.id)

        toast({
          title: "Voice Command",
          description: `${action === "lock" ? "Locked" : "Unlocked"} ${doorToToggle.name} by voice command`,
        })
      }
    } else if (action === "status") {
      toast({
        title: "Door Status",
        description: `You have ${doors.filter((d) => d.status === "locked").length} locked doors and ${doors.filter((d) => d.status === "unlocked").length} unlocked doors.`,
      })
    } else if (action === "help") {
      toast({
        title: "Voice Commands Help",
        description: "You can say: 'lock/unlock door', 'check status', or 'help'",
      })
    }
  }

  // Initialize voice commands
  useVoiceCommands({
    onCommand: handleVoiceCommand,
    enabled: voiceCommandActive,
  })

  const toggleDoorStatus = (doorId) => {
    setDoors(
      doors.map((door) => {
        if (door.id === doorId) {
          const newStatus = door.status === "locked" ? "unlocked" : "locked"

          // Play sound effect
          const audio = new Audio(newStatus === "locked" ? "/lock-sound.mp3" : "/unlock-sound.mp3")
          audio.play().catch((e) => console.log("Audio play failed:", e))

          // Show toast notification
          toast({
            title: `Door ${newStatus}`,
            description: `${door.name} has been ${newStatus}.`,
          })

          return { ...door, status: newStatus }
        }
        return door
      }),
    )
  }

  const toggleAutoLock = (doorId) => {
    setDoors(
      doors.map((door) => {
        if (door.id === doorId) {
          return { ...door, autoLock: !door.autoLock }
        }
        return door
      }),
    )
  }

  const updateSchedule = (doorId, time) => {
    setDoors(
      doors.map((door) => {
        if (door.id === doorId) {
          return { ...door, schedule: time }
        }
        return door
      }),
    )
  }

  const toggleSensor = (sensorId: string) => {
    if (selectedSensors.includes(sensorId)) {
      setSelectedSensors(selectedSensors.filter((id) => id !== sensorId))
    } else {
      setSelectedSensors([...selectedSensors, sensorId])
    }
  }

  const addNewDoor = () => {
    if (!newDoorName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a door name.",
        variant: "destructive",
      })
      return
    }

    // Ensure at least the lock sensor is selected
    if (!selectedSensors.includes("lock")) {
      toast({
        title: "Warning",
        description: "Smart Lock is required and has been automatically selected.",
      })
      setSelectedSensors([...selectedSensors, "lock"])
    }

    const newDoor = {
      id: doors.length + 1,
      name: newDoorName,
      status: "locked",
      battery: 100,
      lastActivity: "Just now",
      schedule: "10:00 PM",
      autoLock: true,
      sensors: selectedSensors,
    }

    setDoors([...doors, newDoor])
    setNewDoorName("")
    setSelectedSensors(["lock"]) // Reset to default for next time

    toast({
      title: "Door Added",
      description: `${newDoorName} has been added to your system with ${selectedSensors.length} sensors.`,
    })
  }

  const sendMessage = () => {
    if (!newMessage.trim()) return

    const message = {
      id: messages.length + 1,
      content: newMessage,
      isAdmin: false,
      timestamp: "Just now",
    }

    setMessages([...messages, message])
    setNewMessage("")
  }

  useEffect(() => {
    const handleClickOutside = (event) => {
      // Simplified event handler
      if (showNotifications || showSettings) {
        const target = event.target
        if (!target.closest(".dropdown-container")) {
          setShowNotifications(false)
          setShowSettings(false)
        }
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [showNotifications, showSettings])

  // Helper to get sensor names for display
  const getSensorNames = (sensorIds: string[]) => {
    return sensorIds.map((id) => availableSensors.find((s) => s.id === id)?.name || id).join(", ")
  }

  if (showBootAnimation) {
    return <BootAnimation onComplete={() => setShowBootAnimation(false)} />
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Atomic Background */}
      <AtomicBackground />

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 bg-black/80 backdrop-blur-lg">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <motion.div className="mr-4 p-2 rounded-full bg-indigo-500/20" whileHover={{ rotate: 10 }}>
              <Home className="h-6 w-6 text-indigo-400" />
            </motion.div>
            <div>
              <motion.h1
                className="text-xl font-bold text-white"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                Smart Door Dashboard
              </motion.h1>
              <motion.p
                className="text-gray-300 text-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                <span className="font-medium">{currentTime}</span> •
                <span className="text-indigo-300 ml-1">System Online</span>
              </motion.p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-300">Voice:</span>
              <Switch
                checked={voiceCommandActive}
                onCheckedChange={setVoiceCommandActive}
                className="data-[state=checked]:bg-indigo-600"
              />
            </div>
            <div className="relative dropdown-container">
              <Button
                variant="outline"
                size="icon"
                className="relative text-white hover:text-white hover:bg-white/10 border-white/20"
                onClick={() => {
                  setShowNotifications(!showNotifications)
                  setShowSettings(false)
                }}
              >
                <Bell className="h-5 w-5" />
                {notifications.filter((n) => !n.read).length > 0 && (
                  <motion.span
                    className="absolute top-0 right-0 w-4 h-4 bg-indigo-500 rounded-full text-[10px] flex items-center justify-center"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring" }}
                  >
                    {notifications.filter((n) => !n.read).length}
                  </motion.span>
                )}
              </Button>

              {showNotifications && (
                <motion.div
                  className="absolute right-0 mt-2 w-80 bg-zinc-900 border border-white/10 rounded-md shadow-lg z-[100]"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <div className="p-3 border-b border-white/10 flex justify-between items-center">
                    <h3 className="font-medium text-white">Notifications</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs text-indigo-400 hover:text-indigo-300"
                      onClick={() => {
                        setNotifications(notifications.map((n) => ({ ...n, read: true })))
                      }}
                    >
                      Mark all as read
                    </Button>
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-3 border-b border-white/10 hover:bg-white/5 cursor-pointer ${!notification.read ? "bg-zinc-800" : ""}`}
                          onClick={() => {
                            setNotifications(
                              notifications.map((n) => (n.id === notification.id ? { ...n, read: true } : n)),
                            )
                          }}
                        >
                          <div className="flex justify-between">
                            <h4 className="font-medium text-white">{notification.title}</h4>
                            {!notification.read && <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>}
                          </div>
                          <p className="text-sm text-gray-300 mt-1">{notification.message}</p>
                          <p className="text-xs text-gray-400 mt-1">{notification.time}</p>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 text-center text-gray-400">No notifications</div>
                    )}
                  </div>
                </motion.div>
              )}
            </div>
            <div className="relative dropdown-container">
              <Button
                variant="outline"
                size="icon"
                className="text-white hover:text-white hover:bg-white/10 border-white/20"
                onClick={() => {
                  setShowSettings(!showSettings)
                  setShowNotifications(false)
                }}
              >
                <Settings className="h-5 w-5" />
              </Button>

              {showSettings && (
                <motion.div
                  className="absolute right-0 mt-2 w-64 bg-zinc-900 border border-white/10 rounded-md shadow-lg z-[100]"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <div className="p-3 border-b border-white/10">
                    <h3 className="font-medium text-white">User Settings</h3>
                  </div>
                  <div>
                    <div className="p-3 border-b border-white/10 hover:bg-white/5 cursor-pointer">
                      <p className="text-sm text-gray-300">Edit Profile</p>
                    </div>
                    <div className="p-3 border-b border-white/10 hover:bg-white/5 cursor-pointer">
                      <p className="text-sm text-gray-300">Change Password</p>
                    </div>
                    <div className="p-3 border-b border-white/10 hover:bg-white/5 cursor-pointer">
                      <p className="text-sm text-gray-300">Notification Settings</p>
                    </div>
                    <div className="p-3 hover:bg-white/5 cursor-pointer">
                      <p className="text-sm text-gray-300">Privacy Settings</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
            <Link href="/admin/login">
              <Button
                variant="outline"
                size="icon"
                className="text-white hover:text-white hover:bg-white/10 border-white/20"
                title="Admin Dashboard"
              >
                <Shield className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/">
              <Button
                variant="outline"
                size="icon"
                className="text-white hover:text-white hover:bg-white/10 border-white/20"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="relative z-10 container mx-auto px-4 py-8">
        <Tabs defaultValue="doors" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-zinc-900/50 border border-white/10">
            <TabsTrigger value="doors" className="data-[state=active]:bg-indigo-600">
              Doors
            </TabsTrigger>
            <TabsTrigger value="messages" className="data-[state=active]:bg-indigo-600">
              Messages
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-indigo-600">
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="doors" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {doors.map((door) => (
                <motion.div
                  key={door.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="bg-zinc-900/80 border-white/10 overflow-hidden">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-white flex justify-between items-center">
                        {door.name}
                        <span
                          className={`text-sm px-2 py-1 rounded ${door.status === "locked" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}
                        >
                          {door.status === "locked" ? "Locked" : "Unlocked"}
                        </span>
                      </CardTitle>
                      <div className="flex justify-between items-center">
                        <p className="text-sm text-gray-300">Last activity: {door.lastActivity}</p>
                        <div className="text-xs text-indigo-300 cursor-help" title={getSensorNames(door.sensors)}>
                          {door.sensors.length} sensors
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <Battery className="h-5 w-5 text-gray-400 mr-2" />
                          <div className="w-full max-w-32">
                            <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${
                                  door.battery > 70
                                    ? "bg-green-500"
                                    : door.battery > 30
                                      ? "bg-yellow-500"
                                      : "bg-red-500"
                                }`}
                                style={{ width: `${door.battery}%` }}
                              ></div>
                            </div>
                          </div>
                          <span className="ml-2 text-sm text-gray-400">{door.battery}%</span>
                        </div>
                      </div>

                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <Clock className="h-5 w-5 text-gray-400 mr-2" />
                          <span className="text-sm text-gray-400">Auto-lock at:</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Input
                            type="time"
                            value={door.schedule}
                            onChange={(e) => updateSchedule(door.id, e.target.value)}
                            className="w-24 h-8 bg-zinc-800 border-zinc-700 text-white text-sm"
                          />
                          <Switch checked={door.autoLock} onCheckedChange={() => toggleAutoLock(door.id)} />
                        </div>
                      </div>

                      <div className="flex justify-center pt-2">
                        <AnimatedDoorLock
                          isLocked={door.status === "locked"}
                          onToggle={() => toggleDoorStatus(door.id)}
                          size="md"
                        />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}

              {/* Add new door card */}
              <Dialog>
                <DialogTrigger asChild>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.2 }}
                  >
                    <Card className="bg-zinc-900/80 border-white/10 h-full min-h-[220px] flex flex-col items-center justify-center cursor-pointer hover:bg-zinc-800/50 transition-colors">
                      <CardContent className="flex flex-col items-center justify-center h-full">
                        <motion.div
                          className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center mb-4"
                          whileHover={{ rotate: 90 }}
                          transition={{ duration: 0.3 }}
                        >
                          <Plus className="h-6 w-6 text-indigo-400" />
                        </motion.div>
                        <p className="text-gray-300">Add New Door</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                </DialogTrigger>
                <DialogContent className="bg-zinc-900 border-white/10 text-white">
                  <DialogHeader>
                    <DialogTitle>Add New Door</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="doorName">Door Name</Label>
                      <Input
                        id="doorName"
                        value={newDoorName}
                        onChange={(e) => setNewDoorName(e.target.value)}
                        placeholder="e.g. Garage Door"
                        className="bg-zinc-800 border-zinc-700 text-white"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label>Select Sensors</Label>
                      <p className="text-xs text-gray-400">Choose which sensors to install on this door</p>

                      <div className="space-y-2 max-h-60 overflow-y-auto pr-2 pt-2">
                        {availableSensors.map((sensor) => (
                          <div key={sensor.id} className="flex items-start space-x-2">
                            <Checkbox
                              id={`sensor-${sensor.id}`}
                              checked={selectedSensors.includes(sensor.id)}
                              onCheckedChange={() => toggleSensor(sensor.id)}
                              disabled={sensor.id === "lock"} // Lock sensor is required
                              className="mt-0.5 data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600"
                            />
                            <div className="grid gap-1.5 leading-none">
                              <label
                                htmlFor={`sensor-${sensor.id}`}
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                {sensor.name}{" "}
                                {sensor.id === "lock" && <span className="text-xs text-indigo-400">(Required)</span>}
                              </label>
                              <p className="text-xs text-gray-400">{sensor.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button onClick={addNewDoor} className="w-full bg-indigo-600 hover:bg-indigo-700">
                      Add Door
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </TabsContent>

          <TabsContent value="messages" className="mt-6">
            <Card className="bg-zinc-900/80 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Messages</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="h-80 overflow-y-auto space-y-4 pr-2">
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        className={`flex ${message.isAdmin ? "justify-start" : "justify-end"}`}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            message.isAdmin ? "bg-zinc-800 text-white" : "bg-indigo-600 text-white"
                          }`}
                        >
                          <p>{message.content}</p>
                          <p className="text-xs opacity-70 mt-1">{message.timestamp}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type your message..."
                      className="bg-zinc-800 border-zinc-700 text-white"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          sendMessage()
                        }
                      }}
                    />
                    <Button onClick={sendMessage} className="bg-indigo-600 hover:bg-indigo-700">
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <Card className="bg-zinc-900/80 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="notifications">Push Notifications</Label>
                    <Switch id="notifications" defaultChecked className="data-[state=checked]:bg-indigo-600" />
                  </div>
                  <p className="text-sm text-gray-300">Receive notifications when door status changes</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="sound">Sound Effects</Label>
                    <Switch id="sound" defaultChecked className="data-[state=checked]:bg-indigo-600" />
                  </div>
                  <p className="text-sm text-gray-300">Play sound when locking or unlocking doors</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="theme">Theme</Label>
                    <RadioGroup defaultValue="dark" className="flex gap-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="dark" id="dark" className="border-white/50" />
                        <Label htmlFor="dark" className="text-sm">
                          Dark
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="system" id="system" className="border-white/50" />
                        <Label htmlFor="system" className="text-sm">
                          System
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                  <p className="text-sm text-gray-300">Choose app appearance</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
