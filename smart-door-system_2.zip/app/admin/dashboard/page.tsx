"use client"

import { Label } from "@/components/ui/label"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import {
  Bell,
  LogOut,
  Search,
  Trash2,
  MessageSquare,
  Shield,
  Users,
  User,
  Mail,
  Calendar,
  Phone,
  MapPin,
  CheckCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { AtomicBackground } from "@/components/atomic-background"

// Mock data for users
const initialUsers = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    location: "New York",
    doorCount: 2,
    lastActive: "Today, 10:23 AM",
    status: "active",
    joinDate: "2023-05-15",
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1 (555) 987-6543",
    location: "Los Angeles",
    doorCount: 1,
    lastActive: "Yesterday, 8:15 PM",
    status: "active",
    joinDate: "2023-06-22",
  },
  {
    id: 3,
    name: "Robert Johnson",
    email: "robert@example.com",
    phone: "+1 (555) 456-7890",
    location: "Chicago",
    doorCount: 3,
    lastActive: "3 days ago",
    status: "inactive",
    joinDate: "2023-04-10",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily@example.com",
    phone: "+1 (555) 234-5678",
    location: "Miami",
    doorCount: 2,
    lastActive: "Just now",
    status: "active",
    joinDate: "2023-07-05",
  },
  {
    id: 5,
    name: "Michael Wilson",
    email: "michael@example.com",
    phone: "+1 (555) 876-5432",
    location: "Seattle",
    doorCount: 1,
    lastActive: "5 days ago",
    status: "inactive",
    joinDate: "2023-03-18",
  },
]

// Mock data for complaints/messages
const initialComplaints = [
  {
    id: 1,
    userId: 1,
    userName: "John Doe",
    userEmail: "john@example.com",
    subject: "Door Lock Malfunction",
    message:
      "My front door lock is not responding to the app. I've tried restarting the app but it's still not working.",
    status: "unresolved",
    date: "Today, 9:30 AM",
    priority: "high",
  },
  {
    id: 2,
    userId: 2,
    userName: "Jane Smith",
    userEmail: "jane@example.com",
    subject: "Battery Draining Too Fast",
    message:
      "The battery on my smart lock is draining very quickly. I just replaced it last week and it's already at 20%.",
    status: "in-progress",
    date: "Yesterday, 2:15 PM",
    priority: "medium",
  },
  {
    id: 3,
    userId: 4,
    userName: "Emily Davis",
    userEmail: "emily@example.com",
    subject: "App Notification Issues",
    message: "I'm not receiving notifications when my door is unlocked. This is a security concern for me.",
    status: "unresolved",
    date: "2 days ago",
    priority: "high",
  },
  {
    id: 4,
    userId: 3,
    userName: "Robert Johnson",
    userEmail: "robert@example.com",
    subject: "Feature Request",
    message:
      "Would it be possible to add a scheduled locking feature? I'd like my doors to automatically lock at certain times.",
    status: "resolved",
    date: "1 week ago",
    priority: "low",
  },
]

export default function AdminDashboard() {
  const { toast } = useToast()
  const [users, setUsers] = useState(initialUsers)
  const [complaints, setComplaints] = useState(initialComplaints)
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("users")
  const [currentTime, setCurrentTime] = useState("")
  const [userToDelete, setUserToDelete] = useState<number | null>(null)
  const [selectedComplaint, setSelectedComplaint] = useState<any | null>(null)
  const [replyText, setReplyText] = useState("")
  const [notifications, setNotifications] = useState([
    { id: 1, title: "New User", message: "Emily Davis has registered", time: "10 minutes ago", read: false },
    { id: 2, title: "New Complaint", message: "John Doe reported an issue", time: "1 hour ago", read: false },
  ])
  const [showNotifications, setShowNotifications] = useState(false)
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")

  // Update current time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const options = {
        hour: "numeric",
        minute: "numeric",
        hour12: true,
      }
      setCurrentTime(now.toLocaleTimeString(undefined, options))
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)

    return () => clearInterval(interval)
  }, [])

  // Handle user deletion
  const confirmDeleteUser = (userId: number) => {
    setUserToDelete(userId)
  }

  const deleteUser = () => {
    if (userToDelete) {
      setUsers(users.filter((user) => user.id !== userToDelete))
      setComplaints(complaints.filter((complaint) => complaint.userId !== userToDelete))

      toast({
        title: "User Deleted",
        description: "The user has been removed from the system",
      })

      setUserToDelete(null)
    }
  }

  // Handle complaint reply
  const sendReply = () => {
    if (!replyText.trim() || !selectedComplaint) return

    // Update complaint status to in-progress if it was unresolved
    if (selectedComplaint.status === "unresolved") {
      setComplaints(
        complaints.map((complaint) =>
          complaint.id === selectedComplaint.id ? { ...complaint, status: "in-progress" } : complaint,
        ),
      )
    }

    toast({
      title: "Reply Sent",
      description: `Your reply to ${selectedComplaint.userName} has been sent.`,
    })

    setReplyText("")
    setSelectedComplaint(null)
  }

  // Handle marking complaint as resolved
  const resolveComplaint = (complaintId: number) => {
    setComplaints(
      complaints.map((complaint) => (complaint.id === complaintId ? { ...complaint, status: "resolved" } : complaint)),
    )

    toast({
      title: "Complaint Resolved",
      description: "The complaint has been marked as resolved.",
    })
  }

  // Filter users based on search term
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.location.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || user.status === statusFilter

    return matchesSearch && matchesStatus
  })

  // Filter complaints based on search term and filters
  const filteredComplaints = complaints.filter((complaint) => {
    const matchesSearch =
      complaint.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.message.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || complaint.status === statusFilter
    const matchesPriority = priorityFilter === "all" || complaint.priority === priorityFilter

    return matchesSearch && matchesStatus && matchesPriority
  })

  return (
    <div className="min-h-screen bg-black text-white">
      <AtomicBackground />

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 bg-black/80 backdrop-blur-lg">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <motion.div className="mr-4 p-2 rounded-full bg-indigo-500/20" whileHover={{ rotate: 10 }}>
              <Shield className="h-6 w-6 text-indigo-400" />
            </motion.div>
            <div>
              <motion.h1
                className="text-xl font-bold text-white"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                Admin Dashboard
              </motion.h1>
              <motion.p
                className="text-gray-300 text-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                <span className="font-medium">{currentTime}</span> •
                <span className="text-indigo-300 ml-1">System Online</span>
              </motion.p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative dropdown-container">
              <Button
                variant="outline"
                size="icon"
                className="relative text-white hover:text-white hover:bg-white/10 border-white/20"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="h-5 w-5" />
                {notifications.filter((n) => !n.read).length > 0 && (
                  <motion.span
                    className="absolute top-0 right-0 w-4 h-4 bg-indigo-500 rounded-full text-[10px] flex items-center justify-center"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring" }}
                  >
                    {notifications.filter((n) => !n.read).length}
                  </motion.span>
                )}
              </Button>

              {showNotifications && (
                <motion.div
                  className="absolute right-0 mt-2 w-80 bg-zinc-900 border border-white/10 rounded-md shadow-lg z-[100]"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <div className="p-3 border-b border-white/10 flex justify-between items-center">
                    <h3 className="font-medium text-white">Notifications</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs text-indigo-400 hover:text-indigo-300"
                      onClick={() => {
                        setNotifications(notifications.map((n) => ({ ...n, read: true })))
                      }}
                    >
                      Mark all as read
                    </Button>
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-3 border-b border-white/10 hover:bg-white/5 cursor-pointer ${!notification.read ? "bg-zinc-800" : ""}`}
                          onClick={() => {
                            setNotifications(
                              notifications.map((n) => (n.id === notification.id ? { ...n, read: true } : n)),
                            )
                          }}
                        >
                          <div className="flex justify-between">
                            <h4 className="font-medium text-white">{notification.title}</h4>
                            {!notification.read && <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>}
                          </div>
                          <p className="text-sm text-gray-300 mt-1">{notification.message}</p>
                          <p className="text-xs text-gray-400 mt-1">{notification.time}</p>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 text-center text-gray-400">No notifications</div>
                    )}
                  </div>
                </motion.div>
              )}
            </div>
            <Link href="/admin/login">
              <Button
                variant="outline"
                size="icon"
                className="text-white hover:text-white hover:bg-white/10 border-white/20"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search users or complaints..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 bg-zinc-800 border-zinc-700 text-white w-64"
            />
          </div>

          <div className="flex gap-2">
            {activeTab === "users" && (
              <select
                className="bg-zinc-800 border border-zinc-700 text-white rounded-md px-3 py-1 text-sm"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="all">All Users</option>
                <option value="active">Active Users</option>
                <option value="inactive">Inactive Users</option>
              </select>
            )}

            {activeTab === "complaints" && (
              <>
                <select
                  className="bg-zinc-800 border border-zinc-700 text-white rounded-md px-3 py-1 text-sm"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">All Statuses</option>
                  <option value="unresolved">Unresolved</option>
                  <option value="in-progress">In Progress</option>
                  <option value="resolved">Resolved</option>
                </select>
                <select
                  className="bg-zinc-800 border border-zinc-700 text-white rounded-md px-3 py-1 text-sm"
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value)}
                >
                  <option value="all">All Priorities</option>
                  <option value="high">High Priority</option>
                  <option value="medium">Medium Priority</option>
                  <option value="low">Low Priority</option>
                </select>
              </>
            )}
          </div>
        </div>

        <Tabs defaultValue="users" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-zinc-900/50 border border-white/10">
            <TabsTrigger value="users" className="data-[state=active]:bg-indigo-600">
              <Users className="mr-2 h-4 w-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="complaints" className="data-[state=active]:bg-indigo-600">
              <MessageSquare className="mr-2 h-4 w-4" />
              Complaints
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-6">
            <Card className="bg-zinc-900/80 border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex justify-between items-center">
                  <span>Registered Users</span>
                  <Badge className="bg-indigo-600">{users.length} Total Users</Badge>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  View and manage all users registered in the system
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border border-white/10 overflow-hidden">
                  <Table>
                    <TableHeader className="bg-zinc-800">
                      <TableRow>
                        <TableHead className="text-gray-300">Name</TableHead>
                        <TableHead className="text-gray-300">Email</TableHead>
                        <TableHead className="text-gray-300">Phone</TableHead>
                        <TableHead className="text-gray-300">Location</TableHead>
                        <TableHead className="text-gray-300">Doors</TableHead>
                        <TableHead className="text-gray-300">Last Active</TableHead>
                        <TableHead className="text-gray-300">Status</TableHead>
                        <TableHead className="text-gray-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.length > 0 ? (
                        filteredUsers.map((user) => (
                          <TableRow key={user.id} className="border-white/10">
                            <TableCell className="font-medium text-white">{user.name}</TableCell>
                            <TableCell className="text-gray-300">{user.email}</TableCell>
                            <TableCell className="text-gray-300">{user.phone}</TableCell>
                            <TableCell className="text-gray-300">{user.location}</TableCell>
                            <TableCell className="text-gray-300">{user.doorCount}</TableCell>
                            <TableCell className="text-gray-300">{user.lastActive}</TableCell>
                            <TableCell>
                              <Badge className={user.status === "active" ? "bg-green-600" : "bg-red-600"}>
                                {user.status === "active" ? "Active" : "Inactive"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="h-8 border-zinc-700 bg-zinc-800 text-white hover:bg-zinc-700"
                                    >
                                      <User className="h-4 w-4 mr-1" /> View
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="bg-zinc-900 border-white/10 text-white">
                                    <DialogHeader>
                                      <DialogTitle>User Details</DialogTitle>
                                      <DialogDescription className="text-gray-400">
                                        Detailed information about {user.name}
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="space-y-4 py-4">
                                      <div className="flex justify-center mb-4">
                                        <div className="w-20 h-20 rounded-full bg-indigo-500/20 flex items-center justify-center">
                                          <User className="h-10 w-10 text-indigo-400" />
                                        </div>
                                      </div>

                                      <div className="space-y-3">
                                        <div className="flex items-center">
                                          <User className="h-4 w-4 text-gray-400 mr-2" />
                                          <span className="text-gray-400 w-24">Name:</span>
                                          <span className="text-white">{user.name}</span>
                                        </div>
                                        <div className="flex items-center">
                                          <Mail className="h-4 w-4 text-gray-400 mr-2" />
                                          <span className="text-gray-400 w-24">Email:</span>
                                          <span className="text-white">{user.email}</span>
                                        </div>
                                        <div className="flex items-center">
                                          <Phone className="h-4 w-4 text-gray-400 mr-2" />
                                          <span className="text-gray-400 w-24">Phone:</span>
                                          <span className="text-white">{user.phone}</span>
                                        </div>
                                        <div className="flex items-center">
                                          <MapPin className="h-4 w-4 text-gray-400 mr-2" />
                                          <span className="text-gray-400 w-24">Location:</span>
                                          <span className="text-white">{user.location}</span>
                                        </div>
                                        <div className="flex items-center">
                                          <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                                          <span className="text-gray-400 w-24">Joined:</span>
                                          <span className="text-white">{user.joinDate}</span>
                                        </div>
                                      </div>

                                      <div className="pt-4 border-t border-white/10">
                                        <h4 className="text-sm font-medium text-gray-300 mb-2">System Access</h4>
                                        <div className="grid grid-cols-2 gap-2">
                                          <div className="bg-zinc-800 p-2 rounded-md">
                                            <p className="text-xs text-gray-400">Doors</p>
                                            <p className="text-lg font-medium text-white">{user.doorCount}</p>
                                          </div>
                                          <div className="bg-zinc-800 p-2 rounded-md">
                                            <p className="text-xs text-gray-400">Status</p>
                                            <p
                                              className={`text-lg font-medium ${user.status === "active" ? "text-green-400" : "text-red-400"}`}
                                            >
                                              {user.status === "active" ? "Active" : "Inactive"}
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </DialogContent>
                                </Dialog>

                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="destructive"
                                      size="sm"
                                      className="h-8"
                                      onClick={() => confirmDeleteUser(user.id)}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="bg-zinc-900 border-white/10 text-white">
                                    <DialogHeader>
                                      <DialogTitle>Confirm Deletion</DialogTitle>
                                      <DialogDescription className="text-gray-400">
                                        Are you sure you want to delete this user? This action cannot be undone.
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="py-4">
                                      <p className="text-white">
                                        You are about to delete <span className="font-bold">{user.name}</span> (
                                        {user.email}).
                                      </p>
                                      <p className="text-gray-400 mt-2">
                                        This will remove all their data from the system, including doors, access logs,
                                        and messages.
                                      </p>
                                    </div>
                                    <DialogFooter>
                                      <Button variant="outline" onClick={() => setUserToDelete(null)}>
                                        Cancel
                                      </Button>
                                      <Button variant="destructive" onClick={deleteUser}>
                                        Delete User
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center text-gray-400 py-4">
                            No users found matching your search criteria.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="complaints" className="mt-6">
            <Card className="bg-zinc-900/80 border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex justify-between items-center">
                  <span>User Complaints</span>
                  <div className="flex gap-2">
                    <Badge className="bg-red-600">
                      {complaints.filter((c) => c.status === "unresolved").length} Unresolved
                    </Badge>
                    <Badge className="bg-yellow-600">
                      {complaints.filter((c) => c.status === "in-progress").length} In Progress
                    </Badge>
                    <Badge className="bg-green-600">
                      {complaints.filter((c) => c.status === "resolved").length} Resolved
                    </Badge>
                  </div>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  View and respond to user complaints and support requests
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border border-white/10 overflow-hidden">
                  <Table>
                    <TableHeader className="bg-zinc-800">
                      <TableRow>
                        <TableHead className="text-gray-300">Status</TableHead>
                        <TableHead className="text-gray-300">User</TableHead>
                        <TableHead className="text-gray-300">Subject</TableHead>
                        <TableHead className="text-gray-300">Priority</TableHead>
                        <TableHead className="text-gray-300">Date</TableHead>
                        <TableHead className="text-gray-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredComplaints.length > 0 ? (
                        filteredComplaints.map((complaint) => (
                          <TableRow key={complaint.id} className="border-white/10">
                            <TableCell>
                              <Badge
                                className={
                                  complaint.status === "resolved"
                                    ? "bg-green-600"
                                    : complaint.status === "in-progress"
                                      ? "bg-yellow-600"
                                      : "bg-red-600"
                                }
                              >
                                {complaint.status === "resolved"
                                  ? "Resolved"
                                  : complaint.status === "in-progress"
                                    ? "In Progress"
                                    : "Unresolved"}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium text-white">{complaint.userName}</TableCell>
                            <TableCell className="text-gray-300">{complaint.subject}</TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  complaint.priority === "high"
                                    ? "bg-red-600/20 text-red-400 border border-red-600/50"
                                    : complaint.priority === "medium"
                                      ? "bg-yellow-600/20 text-yellow-400 border border-yellow-600/50"
                                      : "bg-blue-600/20 text-blue-400 border border-blue-600/50"
                                }
                                variant="outline"
                              >
                                {complaint.priority.charAt(0).toUpperCase() + complaint.priority.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-gray-300">{complaint.date}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="h-8 border-zinc-700 bg-zinc-800 text-white hover:bg-zinc-700"
                                      onClick={() => setSelectedComplaint(complaint)}
                                    >
                                      <MessageSquare className="h-4 w-4 mr-1" /> Reply
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="bg-zinc-900 border-white/10 text-white">
                                    <DialogHeader>
                                      <DialogTitle>Reply to Complaint</DialogTitle>
                                      <DialogDescription className="text-gray-400">
                                        Send a response to {selectedComplaint?.userName}
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="space-y-4 py-4">
                                      <div className="bg-zinc-800 p-4 rounded-md">
                                        <div className="flex justify-between items-start mb-2">
                                          <div>
                                            <h4 className="font-medium text-white">{selectedComplaint?.subject}</h4>
                                            <p className="text-xs text-gray-400">
                                              From: {selectedComplaint?.userName} ({selectedComplaint?.userEmail})
                                            </p>
                                          </div>
                                          <Badge
                                            className={
                                              selectedComplaint?.priority === "high"
                                                ? "bg-red-600/20 text-red-400 border border-red-600/50"
                                                : selectedComplaint?.priority === "medium"
                                                  ? "bg-yellow-600/20 text-yellow-400 border border-yellow-600/50"
                                                  : "bg-blue-600/20 text-blue-400 border border-blue-600/50"
                                            }
                                            variant="outline"
                                          >
                                            {selectedComplaint?.priority.charAt(0).toUpperCase() +
                                              selectedComplaint?.priority.slice(1)}{" "}
                                            Priority
                                          </Badge>
                                        </div>
                                        <p className="text-gray-300 text-sm mt-2">{selectedComplaint?.message}</p>
                                        <p className="text-xs text-gray-500 mt-2">{selectedComplaint?.date}</p>
                                      </div>

                                      <div className="space-y-2">
                                        <Label htmlFor="reply">Your Reply</Label>
                                        <textarea
                                          id="reply"
                                          value={replyText}
                                          onChange={(e) => setReplyText(e.target.value)}
                                          placeholder="Type your response here..."
                                          className="w-full h-32 bg-zinc-800 border-zinc-700 text-white rounded-md p-2"
                                        />
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button variant="outline" onClick={() => setSelectedComplaint(null)}>
                                        Cancel
                                      </Button>
                                      <Button onClick={sendReply} className="bg-indigo-600 hover:bg-indigo-700">
                                        Send Reply
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>

                                {complaint.status !== "resolved" && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="h-8 border-green-700 bg-green-800/20 text-green-400 hover:bg-green-800/40"
                                    onClick={() => resolveComplaint(complaint.id)}
                                  >
                                    <CheckCircle className="h-4 w-4 mr-1" /> Resolve
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-gray-400 py-4">
                            No complaints found matching your search criteria.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
