"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ArrowRight, Lock, Shield, Bell, Settings, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function Home() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState(null)
  const [systemStatus, setSystemStatus] = useState("online")

  // Mock authentication check
  useEffect(() => {
    // Simulate loading delay
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] opacity-10"></div>
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12 relative z-10">
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="flex justify-between items-center mb-16"
        >
          <div className="flex items-center">
            <Lock className="h-8 w-8 text-blue-400 mr-2" />
            <h1 className="text-2xl font-bold">Smart Door System</h1>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`h-2 w-2 rounded-full ${systemStatus === "online" ? "bg-green-500" : "bg-red-500"}`}></div>
            <span className="text-sm text-gray-300">System {systemStatus}</span>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
            <motion.h2 variants={itemVariants} className="text-4xl md:text-5xl font-bold leading-tight">
              Secure Access Control <br />
              <span className="text-blue-400">For Your Smart Home</span>
            </motion.h2>

            <motion.p variants={itemVariants} className="text-lg text-gray-300 max-w-lg">
              Monitor and control your doors from anywhere. Get real-time notifications, manage access, and enhance your
              home security.
            </motion.p>

            <motion.div variants={itemVariants} className="flex flex-wrap gap-4 pt-4">
              <Button
                onClick={() => router.push("/login")}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 rounded-lg text-lg flex items-center"
              >
                Login <ArrowRight className="ml-2 h-5 w-5" />
              </Button>

              <Button
                onClick={() => router.push("/signup")}
                variant="outline"
                className="border-blue-400 text-blue-400 hover:bg-blue-400/10 px-8 py-6 rounded-lg text-lg"
              >
                Sign Up
              </Button>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative"
          >
            <div className="relative bg-gray-800/50 backdrop-blur-sm p-6 rounded-2xl border border-gray-700 shadow-xl">
              <div className="absolute -top-3 -right-3 bg-blue-500 text-white p-2 rounded-full">
                <Shield className="h-5 w-5" />
              </div>

              <h3 className="text-xl font-semibold mb-4">Smart Door Features</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-4 flex items-start space-x-3">
                    <Lock className="h-5 w-5 text-blue-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Remote Access</h4>
                      <p className="text-sm text-gray-400">Lock or unlock from anywhere</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-4 flex items-start space-x-3">
                    <Bell className="h-5 w-5 text-blue-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Notifications</h4>
                      <p className="text-sm text-gray-400">Real-time alerts</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-4 flex items-start space-x-3">
                    <User className="h-5 w-5 text-blue-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium">User Management</h4>
                      <p className="text-sm text-gray-400">Control who has access</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-4 flex items-start space-x-3">
                    <Settings className="h-5 w-5 text-blue-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Custom Settings</h4>
                      <p className="text-sm text-gray-400">Personalize your system</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
